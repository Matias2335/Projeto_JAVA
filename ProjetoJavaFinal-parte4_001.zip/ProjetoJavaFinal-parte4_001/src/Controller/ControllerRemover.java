/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import DAO.ClienteDAO;
import DAO.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Entrada_Cadastro;
import view.TelaGerente;

/**
 *
 * @author guilh
 */
public class ControllerRemover {
    private TelaGerente view;
    private Entrada_Cadastro cadastro;
    public ControllerRemover(TelaGerente view,Entrada_Cadastro cadastro){
        this.view = view;
        this.cadastro = cadastro;
    
    }
    public void remover() {
    int option = JOptionPane.showConfirmDialog(view, "Deseja realmente excluir o cadastro", "Aviso", JOptionPane.YES_NO_OPTION);
    
    if (option == JOptionPane.YES_OPTION) { 
        Conexao conexao = new Conexao();
        
        try {
            Connection conn = conexao.getConnection();
            ClienteDAO dao = new ClienteDAO(conn);
            dao.remover(cadastro);
            JOptionPane.showMessageDialog(view, "Usuário removido com Sucesso!", "Aviso", JOptionPane.INFORMATION_MESSAGE);
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(view, "Falha de conexão!", "Erro", JOptionPane.ERROR_MESSAGE);
        }
    }
}

}