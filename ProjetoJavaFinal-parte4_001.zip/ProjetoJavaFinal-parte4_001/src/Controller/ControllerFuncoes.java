/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;
import model.FuncSalario;
import view.Cliente;
import model.FuncCorrente;
/**
 *
 * @author fabio
 */
public class ControllerFuncoes {
    private Cliente view;
    private String n1,n2;
    
    public ControllerFuncoes(Cliente view){
        this.view = view;
    }
    
    public void salario(){
        FuncSalario funcoes = new FuncSalario();
        String valor = view.getEntrrada_valor().getText();
        Double valor_double = Double.parseDouble(valor);
        view.getEntrrada_valor().setText(String.valueOf(funcoes.calcular(valor_double)));
    }
    public void corrente(){
        FuncCorrente funcoes = new FuncCorrente();
        String valor = view.getEntrrada_valor().getText();
        Double valor_double = Double.parseDouble(valor);
        view.getEntrrada_valor().setText(String.valueOf(funcoes.calcular(valor_double)));
     
}
}