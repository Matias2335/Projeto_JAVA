
package controller;

import DAO.ClienteDAO;
import DAO.Conexao;
import java.sql.Connection;
import java.sql.SQLException;
import javax.swing.JOptionPane;

import model.Entrada_Cadastro;
import view.Cliente;
import view.Gerente;

public class ControllerCadastro {
    private Cliente view;
    public ControllerCadastro(Cliente view){
        this.view = view;
    }
    
    public void salvarCadastro(){
        String nome = view.getEntrada_nome().getText();
        String cpf = view.getEntrada_cpf().getText();
        String senha = view.getEntrada_senha().getText();
        String valor = view.getEntrrada_valor().getText();
        Entrada_Cadastro cadastro = new Entrada_Cadastro(nome,cpf,senha,valor);
        
        Conexao conexao = new Conexao();
        try {
            Connection conn = conexao.getConnection();
            ClienteDAO dao = new ClienteDAO(conn);
            dao.inserir(cadastro);
            JOptionPane.showMessageDialog(view, "Falha","Erro", JOptionPane.ERROR);
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(view, "Usuario Cadastrado!","Aviso", JOptionPane.INFORMATION_MESSAGE);
            
            ex.printStackTrace();
        }
    }
}

