
package controller;

import DAO.ClienteDAO;
import DAO.Conexao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.JOptionPane;
import model.Entrada_Cadastro;
import view.Exibir_Conta;
import view.Exibir_Saldo;
import view.Tela_Extrato;


public class ControllerLogin {
    private Tela_Extrato view;
    
    public ControllerLogin(Tela_Extrato view){
        this.view = view;
    }

  
     public void loginCliente(){
        String cpf = view.getEntrada_cpf().getText();
        String senha = view.getEntrada_senha().getText();
        Entrada_Cadastro cadastro = new Entrada_Cadastro(cpf,senha);
        Conexao conexao = new Conexao();
        try{
            Connection conn = conexao.getConnection();
            ClienteDAO dao = new ClienteDAO(conn);
            ResultSet res = dao.consultar(cadastro);
            
            if(res.next()){
                JOptionPane.showMessageDialog(view, "Login Feito", "Aviso", JOptionPane.INFORMATION_MESSAGE);
                String nome = res.getString("nome");
                String CPF = res.getString("cpf");
                String Senha = res.getString("senha");
                String valor = res.getString("valor");
                Exibir_Saldo viewExibir = new Exibir_Saldo(new Entrada_Cadastro(nome, CPF, Senha , valor));
                viewExibir.setVisible(true);
                view.setVisible(false);

            } else{
                JOptionPane.showMessageDialog(view, "Login não efetuado", "Erro", JOptionPane.ERROR_MESSAGE);
                
            }
        } catch(SQLException e){
            JOptionPane.showMessageDialog(view, "Erro de conexão", "Erro", JOptionPane.ERROR_MESSAGE);
                
        }
    }
}
 