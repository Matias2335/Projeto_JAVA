
package projeto_java;

import view.Entrada;
import DAO.ClienteDAO;
import DAO.Conexao;
import java.util.logging.Logger;
import java.util.logging.Level;
import view.Cliente;
import java.sql.Connection;
import java.sql.SQLException;


/**
 *
 * @author guilh
 */
public class Projeto_Java {

   
    public static void main(String[] args) {
        Entrada e = new Entrada();
        e.setVisible(true);
        
    }
    
}
