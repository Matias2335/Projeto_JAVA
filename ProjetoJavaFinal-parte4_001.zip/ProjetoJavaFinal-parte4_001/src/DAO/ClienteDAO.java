package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import model.Entrada_Cadastro;

public class ClienteDAO {
    private Connection conn;

    public ClienteDAO(Connection conn) {
        this.conn = conn;
    }

    public void inserir(Entrada_Cadastro cadastro) throws SQLException {
        String sql = "INSERT INTO cadastro (nome, cpf, senha, valor) VALUES (?, ?, ?, ?)";

        try (PreparedStatement statement = conn.prepareStatement(sql)) {
            statement.setString(1, cadastro.getNome());
            statement.setString(2, cadastro.getCpf());
            statement.setString(3, cadastro.getSenha());
            statement.setString(4, cadastro.getValor());

            statement.executeUpdate();

            conn.commit();
        } catch (SQLException ex) {
            conn.rollback();
            throw ex;
        }
    }

    public ResultSet consultar(Entrada_Cadastro cadastro) throws SQLException {
        String sql = "SELECT * FROM cadastro WHERE cpf = ? AND senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, cadastro.getCpf());
        statement.setString(2, cadastro.getSenha());
        statement.execute();
        return statement.getResultSet();
    }

    public void remover(Entrada_Cadastro cadastro) throws SQLException {
        String sql = "DELETE FROM cadastro WHERE cpf = ? AND senha = ?";
        PreparedStatement statement = conn.prepareStatement(sql);
        statement.setString(1, cadastro.getCpf());
        statement.setString(2, cadastro.getSenha());
        statement.executeUpdate();
    }

   
}
